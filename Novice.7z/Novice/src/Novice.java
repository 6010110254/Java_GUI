import java.util.*;
import java.util.Scanner;
public  class Novice {
	private static int HP=100;
	private static int level;
	private static String career;
	private static int Countkill=0;

	public static void setHP(int H) {
		HP = H;
	}
	public static void setHPUp(int UP) {
		HP +=UP; 
	}
	public static void setCountkill(int UP) {
		Countkill +=UP; 
	}
	public static int getCountkill() {
		return Countkill; 
	}
	public static void setHPDown(int DW) {
		HP +=DW; 
	}
	public static void setlevel(int L) {
		level = L;
	}
	public static void setlevelUp(int UP) {
		level +=UP; 
	}
	public static void setCareer(String S) {
		career = S;
	}
	public static String getCareer() {
		return career;
	}
	public static int getHP() {
		if (HP > 0 ) {
		return HP;
		}

		return 0;
	}
	public static int getLevel() {
		if (level < 100 ) {
		return level;
		}
		else
			return 100;
	}



}
