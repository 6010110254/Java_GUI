import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;

public class PAbout extends JPanel {

	/**
	 * Create the panel.
	 */
	public PAbout() {
		
		JLabel lblByFadel = new JLabel("By Fadel Hayeemareh \n 6010110254");
		lblByFadel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		add(lblByFadel);

	}

}
