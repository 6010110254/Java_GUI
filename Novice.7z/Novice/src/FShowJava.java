import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.imageio.ImageIO;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;



public class FShowJava extends JFrame  {
	private JTextField txtSelectCareer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {


		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FShowJava frame = new FShowJava();
					frame.setSize(323, 301);
					frame.setVisible(true);


				} catch (Exception e) {
					e.printStackTrace();

				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public FShowJava() {
		  bag m3 = new bag();
		  Farm m4 = new Farm();
		  String s = null;
		Scanner scanner = new Scanner(System.in);
		setTitle("Game RanThai");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\\\Users\\\\6010110254\\\\eclipse-workspace\\\\Novice\\\\src\\\\.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 323, 301);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmNew = new JMenuItem("New");

		mnFile.add(mntmNew);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}

		});
		mnFile.add(mntmExit);
		
		JMenu mnAbout = new JMenu("About");
		menuBar.add(mnAbout);
		
		JMenuItem mntmAboutMe = new JMenuItem("About Me.");
		mntmAboutMe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PAbout Pab = new PAbout ();
				setContentPane(Pab);
				setVisible(true);
			}
		});
		mnAbout.add(mntmAboutMe);
		Icon icon1 = new ImageIcon("C:\\\\Users\\\\6010110254\\\\eclipse-workspace\\\\Novice\\\\src\\\\Sword.gif");
		Icon icon2 = new ImageIcon("C:\\\\Users\\\\6010110254\\\\eclipse-workspace\\\\Novice\\\\src\\\\archer1.gif");
		Panel panel = new Panel();
		Panel panel_2 = new Panel();
		panel_2.setBounds(23, 0, 73, 99);
		getContentPane().add(panel_2);

		JLabel jL1 = new JLabel("",icon1,SwingConstants.LEFT);
		panel_2.add(jL1);
		
		Panel panel_3 = new Panel();
		panel_3.setBounds(23, 85, 73, 95);
		getContentPane().add(panel_3);
		
			JLabel jL2 = new JLabel("",icon2,SwingConstants.LEFT);
			panel_3.add(jL2);
		
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		JPanel panel_1 = new JPanel();
		panel.add(panel_1);
		panel_1.setLayout(null);
		JLabel lblSelectCareer_1 = new JLabel("Select Career");
		lblSelectCareer_1.setBounds(119, 11, 119, 14);
		getContentPane().add(lblSelectCareer_1);
//		
//		JLabel lblStatus = new JLabel("Status Novice ");
//		lblStatus.setBounds(417, 32, 127, 49);
//		getContentPane().add(lblStatus);
//		
//		
	JLabel lblNewLabel_1 = new JLabel("Level your is :"+ Novice.getLevel());
		lblNewLabel_1.setBounds(388, 119, 144, 23);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("HP your is :"+ Novice.getHP());
		lblNewLabel_2.setBounds(388, 153, 132, 19);
		getContentPane().add(lblNewLabel_2);
		
		getContentPane().setLayout(null);
		// Radio Button
		final JRadioButton radio1 = new JRadioButton("Sword man");
		radio1.setBounds(119, 32, 109, 23);
		getContentPane().add(radio1);
		final JRadioButton radio2 = new JRadioButton("Archer");
		radio2.setBounds(119, 105, 109, 23);
		getContentPane().add(radio2);
		// Set Group
		ButtonGroup group = new ButtonGroup();
		group.add(radio1);
		group.add(radio2);
		

		JButton btn = new JButton("Button");
		btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			//  final ImageIcon ibat = new ImageIcon(getClass().getResource("monster.png"));
		// Check Checkbox 1
		if(radio1.isSelected()){
			Novice.setCareer("Sword man");
			Novice.setHP(100);
	
		    JOptionPane.showMessageDialog(null,"You select : Sword man\nMonster \n1.Hippocampus(Level 45) Damage 35 \n2. Golem (Level 23) Damage 20 \n3. Kong (Level 6) Damage 13");

            //JOptionPane.showMessageDialog(null,"You W",JOptionPane.INFORMATION_MESSAGE,ibat);
       
		} else if (radio2.isSelected()) {
			Novice.setCareer("Archer");
			Novice.setHP(100);
		JOptionPane.showMessageDialog(null,"You select : Archer\nMonster \n1.Hippocampus(Level 45) Damage 35 \n2. Golem (Level 23) Damage 20 \n3. Kong (Level 6) Damage 13");

		}
		else {
		JOptionPane.showMessageDialog(null,"You not select.");
		}
		
		

	        int choice = 0;
	        int choice1 = 0;
			int choice2 = 0;
			int choice3 = 0;
			int choice4 = 0;
			int choice5 = 0;
			int choice6 = 0;
			//int countkill =0;
			Novice.setHP(100);
			
	      while (( Novice.getHP() > 0) && (Novice.getLevel() < 100)) {
	    	 // JLabel O = new JLabel("HP your is :"+Novice.getHP()+"\nLevel your is :"+ Novice.getLevel()+"\nScore your kill:"+ Novice.getCountkill());
	    	//  panel_4.add(O);
	    	//  panel_4.
    	  JOptionPane.showMessageDialog(null," HP your is :"+Novice.getHP()+"     Energy :"+ m3.getEnergy()+"\nLevel your is :"+ Novice.getLevel()+"     Banned :"+m3.getBanned()+"\nScore your kill:"+ Novice.getCountkill()+"     Medkid : "+m3.getMedkid());

	    	  System.out.println("_________________________________");
	  		System.out.println("Choose What wiil you do ?");
	            System.out.println("1. Farm");
	            System.out.println("2. Watch bag");
	            System.out.println("3. Get Item");
	            System.out.print("Choice:");
	        choice  = scanner.nextInt();
	        
			 if(choice == 1){
				 Novice.setCountkill(1);
					m4.Fight();
		            } 
		     else if (choice == 2){
			        System.out.println("============Bag===============");
			        System.out.println("Enegy = "+ m3.getEnergy());
			        System.out.println("Banned = "+ m3.getBanned());
			        System.out.println("Medkid = "+ m3.getMedkid());
			        System.out.println("============Bag===============");
			        System.out.println("1.Use Item ");
			        System.out.println("2.Description Item ");
			        System.out.println("3.Back ");
			        System.out.print("Choice:");
			        choice3  = scanner.nextInt();
			        if(choice3 == 1) {        	
				        System.out.println("1.Enegy = "+ m3.getEnergy());
				        System.out.println("2.Banned = "+ m3.getBanned());
				        System.out.println("3.Medkid = "+ m3.getMedkid());

		       System.out.print("Choice:");
		       choice4  = scanner.nextInt();
		       if(choice4 == 1) {
		    	   if (m3.getEnergy() > 0) {
		      m3.setEnergyUp(-1);
		      Novice.setHPUp(5);
				 System.out.println("HP Novice : "+ Novice.getHP());}
		          else {
				 System.out.println("Your item has no. ");
		          }

		       }
		       else if (choice4 == 2) {
		    	   if (m3.getBanned() > 0) {
		      m3.setBannedUp(-1);
		      Novice.setHPUp(10); 
				 System.out.println("HP Novice : "+ Novice.getHP());}
		          else {
				 System.out.println("Your item has no. ");
		          }

		       }
		       else if (choice4 == 3) {
		    	   if (m3.getMedkid() > 0) {
		       	m3.setMedkidUp(-1);
		       	Novice.setHPUp(35);
				System.out.println("HP Novice : "+ Novice.getHP());
		       	}
		          else {
				 System.out.println("Your item has no. ");
		          }

		       }
			  }
			   else if (choice3 == 2){
			        System.out.println("1.Enegy ");
			        System.out.println("2.Banned ");
			        System.out.println("3.Medkid  ");
			        System.out.print("Choice:");
			        choice5  = scanner.nextInt();
			        if(choice5 == 1) {
			           System.out.println("���Ҵ����١��ѧ + ���ʹ  : 5 HP");
			           }
			           else if (choice5 == 2) {
			           System.out.println("��Ҿѹ�� + ���ʹ :  10 HP");
			           }
			           else if (choice5 == 3) {
			           System.out.println("�ش�����Һ�� + ���ʹ :  35 HP");

			           }
			   }
		
		     } 	   
		     else if (choice == 3){
		         System.out.println("1. Energy Drink ");
		         System.out.println("2. Banned");
		         System.out.println("3. Medkit");
		         System.out.print("Choice:");
		         choice6  = scanner.nextInt();
		         if (choice6 == 1) {
		         	m3.setEnergyUp(1);
		         }
		         else if (choice6 == 2) {
		         	m3.setBannedUp(1);     	 
		         }
		         else if (choice6 == 3) {
		         	m3.setMedkidUp(1);
		         }
		 		
		     } 
			 
	   	  System.out.println("_________________________________");
	   	  System.out.println("____________Please OK___________");
	        }
	       if (Novice.getLevel() >= 100 ) {
	    	   JOptionPane.showMessageDialog(null,"=======================\nYou Win !! :) \nHP : " + Novice.getHP()+"\nLevel  = 100 \nThank you For playing\n=======================");
//	        System.out.println("=======================");
//	        System.out.println("You Win !! :) ");
//	 		System.out.println("HP = " + Novice.getHP());
//	 		System.out.println("Level  = 100 ");
//	 		System.out.println("Thank you For playing");
//	        System.out.println("=======================");
	       }
	       else if (Novice.getHP()<= 0) {
	    	   JOptionPane.showMessageDialog(null,"=======================\nYou lost !! :( \nHP = 0 \nLevel  :"+ Novice.getLevel()+" \nThank you For playing\n=======================");
//		        System.out.println("=======================");
//	           System.out.println("=======================");
//	           System.out.println("You lost !! :( ");
//	    		System.out.println("HP = 0 ");
//	    		System.out.println("Thank you For playing");
//
//	           System.out.println("=======================");
	    	   
	       }

	       
	       
		}
		
		});
		btn.setBounds(125, 154, 89, 23);
		getContentPane().add(btn); 
		
		JLabel lblLevelUp = new JLabel("Level UP 100 Your Win !!");
		lblLevelUp.setBounds(58, 186, 170, 14);
		getContentPane().add(lblLevelUp);
		
		JLabel lblHpYour = new JLabel("HP Your = 0 Your Lost :(");
		lblHpYour.setBounds(58, 211, 156, 14);
		getContentPane().add(lblHpYour);
		

		

		

		


	



	}
}
