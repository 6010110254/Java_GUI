import java.util.*;
public class bag {
	//bag m3 = new bag();
	private  int Energy ;
	private  int Banned ;
	private  int Medkid;

	public bag() {
		this.Energy = 0;
		this.Banned = 0;
		this.Medkid = 0;
	}
	
	public void setEnergyUp(int UP) {
		Energy +=UP;
	}
	public void setBannedUp(int UP) {
		Banned +=UP; 
	}
	public void setMedkidUp(int UP) {
		Medkid +=UP; 
	}
	public int getEnergy() {
		return Energy ;
	}
	public int getBanned() {
		return Banned ;
	}
	public int getMedkid() {
		return Medkid ;
	}
		 
}
