import java.util.*;
import java.util.Scanner;
public  class Novice {


	public static int HP = 100;
	public static int level ;
	 String career;

}
