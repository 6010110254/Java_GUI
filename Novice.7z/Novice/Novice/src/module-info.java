/**
 * 
 */
/**
 * @author Fadel
 *
 */
module Novice {
}